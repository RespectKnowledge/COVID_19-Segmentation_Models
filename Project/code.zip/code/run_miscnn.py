
import tensorflow as tf
from miscnn.data_loading.interfaces import NIFTI_interface
from miscnn import Data_IO, Preprocessor, Data_Augmentation, Neural_Network
from miscnn.processing.subfunctions import Normalization, Clipping, Resampling
from miscnn.neural_network.architecture.unet.standard import Architecture
from miscnn.neural_network.metrics import tversky_crossentropy, dice_soft, \
                                          dice_crossentropy, tversky_loss
from miscnn.evaluation.cross_validation import cross_validation
from tensorflow.keras.callbacks import ReduceLROnPlateau, TensorBoard, \
                                       EarlyStopping, CSVLogger
from miscnn.evaluation.cross_validation import run_fold, load_csv2fold
import argparse
import os


physical_devices = tf.config.experimental.list_physical_devices('GPU')

tf.config.experimental.set_memory_growth(physical_devices[0], True)

parser = argparse.ArgumentParser(description="Automated COVID-19 Segmentation")
parser.add_argument("-f","--fold ", help="Cross-validation fold. Range: [0:5]",
                    required=True, type=int, dest="fold")
args = parser.parse_args()
fold = args.fold
fold_subdir = os.path.join("evaluation", "fold_" + str(fold))


#using 4 classes due to [background, lung_left, lung_right, covid-19]
interface = NIFTI_interface(channels=1, classes=4)

# Create Data IO object to load and write samples in the file structure
data_io = Data_IO(interface, input_path="data", delete_batchDir=False)

# Access all available samples in our file structure
sample_list = data_io.get_indiceslist()
sample_list.sort()

# Create and configure the Data Augmentation class
data_aug = Data_Augmentation(cycles=1, scaling=True, rotations=True,
                             elastic_deform=True, mirror=True,
                             brightness=True, contrast=True, gamma=True,
                             gaussian_noise=True)

# Create a clipping Subfunction to the lung window of CTs (-1250 and 250)
sf_clipping = Clipping(min=-1250, max=250)
# Create a pixel value normalization Subfunction to scale between 0-255转化为灰度图像
sf_normalize = Normalization(mode="grayscale")
# Create a resampling Subfunction to voxel spacing 1.58 x 1.58 x 2.70
sf_resample = Resampling((1.58, 1.58, 2.70))
# Create a pixel value normalization Subfunction for z-score scaling创建用于z分数缩放的像素值归一化子功能
sf_zscore = Normalization(mode="z-score")

# Assemble Subfunction classes into a list
sf = [sf_clipping, sf_normalize, sf_resample, sf_zscore]

# Create and configure the Preprocessor class创建和配置Preprocessor类
pp = Preprocessor(data_io, data_aug=data_aug, batch_size=1, subfunctions=sf,
                  prepare_subfunctions=True, prepare_batches=False,
                  analysis="patchwise-crop", patch_shape=(160, 160, 80))
# Adjust the patch overlap for predictions调整补丁重叠以进行预测
pp.patchwise_overlap = (80, 80, 40)

# Initialize the Architecture初始化架构
unet_standard = Architecture(depth=4, activation="softmax",
                             batch_normalization=True)

# Create the Neural Network model
model = Neural_Network(preprocessor=pp, architecture=unet_standard,
                       loss=tversky_crossentropy,
                       metrics=[tversky_loss, dice_soft, dice_crossentropy],
                       batch_queue_size=3, workers=1, learninig_rate=0.0001)

# Define Callbacks
cb_lr = ReduceLROnPlateau(monitor='loss', factor=0.1, patience=15,
                          verbose=1, mode='min', min_delta=0.0001, cooldown=1,
                          min_lr=0.00001)
cb_es = EarlyStopping(monitor="loss", patience=100)
cb_tb = TensorBoard(log_dir=os.path.join(fold_subdir, "tensorboard"),
                    histogram_freq=0, write_graph=True, write_images=True)
cb_cl = CSVLogger(os.path.join(fold_subdir, "logs.csv"), separator=',',
                  append=True)


# Run pipeline for cross-validation fold 运行管道进行交叉验证折叠
run_fold(fold, model, epochs=10, iterations=150, evaluation_path="evaluation",
         draw_figures=True, callbacks=[cb_lr, cb_es, cb_tb, cb_cl],
         save_models=False)

# Dump model to disk for reproducibility将模型转储到磁盘以提高再现性
model.dump(os.path.join(fold_subdir, "model.hdf5"))


# Obtain training and validation data set获取培训和验证数据集
training, validation = load_csv2fold(os.path.join(fold_subdir,"sample_list.csv"))
# Compute predictions
model.predict(validation, direct_output=False)
